import settings from './settings';

export default {
    openGui: function() {
        new Gui()
            .registerDraw((x, y, gui, event) => {
                // Draw background
                Renderer.drawRect(Renderer.color(0, 0, 0, 150), 50, 50, 300, 250);
                Renderer.drawString("Sound Trigger:", 60, 70);
                Renderer.drawString("Audio URL:", 60, 110);
                Renderer.drawString("Image Trigger:", 60, 150);
                Renderer.drawString("Image URL:", 60, 190);
                Renderer.drawString("Image Duration:", 60, 230);
                Renderer.drawString("On Death:", 60, 270);
                Renderer.drawString("Death Audio URL:", 60, 310);

                // Draw input fields
                const triggerField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 65, 150, 20);
                triggerField.setMaxStringLength(32);
                triggerField.setText(settings.getSoundTrigger().trigger);
                triggerField.drawTextBox();

                const urlField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 105, 150, 20);
                urlField.setMaxStringLength(256);
                urlField.setText(settings.getSoundTrigger().url);
                urlField.drawTextBox();

                const imageTriggerField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 145, 150, 20);
                imageTriggerField.setMaxStringLength(32);
                imageTriggerField.setText(settings.getImageTrigger().trigger);
                imageTriggerField.drawTextBox();

                const imageUrlField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 185, 150, 20);
                imageUrlField.setMaxStringLength(256);
                imageUrlField.setText(settings.getImageTrigger().url);
                imageUrlField.drawTextBox();

                const imageDurationField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 225, 150, 20);
                imageDurationField.setMaxStringLength(4);
                imageDurationField.setText(settings.getImageTrigger().duration.toString());
                imageDurationField.drawTextBox();

                const onDeathField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 265, 150, 20);
                onDeathField.setMaxStringLength(5);
                onDeathField.setText(settings.getImageTrigger().onDeath.toString());
                onDeathField.drawTextBox();

                const deathUrlField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 305, 150, 20);
                deathUrlField.setMaxStringLength(256);
                deathUrlField.setText(settings.getDeathSoundUrl());
                deathUrlField.drawTextBox();
            })
            .registerMouseClick((x, y, button, event) => {
                // Save new settings on click
                const triggerField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 65, 150, 20);
                const urlField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 105, 150, 20);
                const imageTriggerField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 145, 150, 20);
                const imageUrlField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 185, 150, 20);
                const imageDurationField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 225, 150, 20);
                const onDeathField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 265, 150, 20);
                const deathUrlField = new TextField(Minecraft.getMinecraft().field_71456_v, 150, 305, 150, 20);

                settings.setSoundTrigger(triggerField.getText(), urlField.getText());
                settings.setImageTrigger(imageTriggerField.getText(), imageUrlField.getText(), parseInt(imageDurationField.getText()), onDeathField.getText() === "true");
                settings.setDeathSoundUrl(deathUrlField.getText());

                ChatLib.chat("Sound trigger set to: " + triggerField.getText());
                ChatLib.chat("Audio URL set to: " + urlField.getText());
                ChatLib.chat("Image trigger set to: " + imageTriggerField.getText());
                ChatLib.chat("Image URL set to: " + imageUrlField.getText());
                ChatLib.chat("Image duration set to: " + imageDurationField.getText() + " seconds");
                ChatLib.chat("On death: " + onDeathField.getText());
                ChatLib.chat("Death audio URL set to: " + deathUrlField.getText());
            })
            .open();
    }
};
