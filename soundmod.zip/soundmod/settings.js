let soundTrigger = {
    trigger: "trigger",
    url: "http://example.com/audio.mp3"
};

let imageTrigger = {
    trigger: "imageTrigger",
    url: "http://example.com/image.png",
    duration: 5,
    onDeath: false
};

let deathSoundUrl = "http://example.com/death_audio.mp3";

export default {
    getSoundTrigger: function() {
        return soundTrigger;
    },
    setSoundTrigger: function(newTrigger, newUrl) {
        soundTrigger.trigger = newTrigger;
        soundTrigger.url = newUrl;
    },
    getImageTrigger: function() {
        return imageTrigger;
    },
    setImageTrigger: function(newTrigger, newUrl, newDuration, newOnDeath) {
        imageTrigger.trigger = newTrigger;
        imageTrigger.url = newUrl;
        imageTrigger.duration = newDuration;
        imageTrigger.onDeath = newOnDeath;
    },
    getDeathSoundUrl: function() {
        return deathSoundUrl;
    },
    setDeathSoundUrl: function(newUrl) {
        deathSoundUrl = newUrl;
    }
};
