import settings from './settings';
import gui from './gui';

// Play sound and display image on specific chat message
register("chat", (event) => {
    const message = ChatLib.getChatMessage(event);
    const soundTrigger = settings.getSoundTrigger();
    const imageTrigger = settings.getImageTrigger();

    if (message.includes(soundTrigger.trigger)) {
        playSound(soundTrigger.url);
    }
    if (message.includes(imageTrigger.trigger)) {
        displayImage(imageTrigger.url, imageTrigger.duration);
    }
}).setChatCriteria("${message}");

// Play sound on death
register("death", () => {
    const deathSoundUrl = settings.getDeathSoundUrl();
    playSound(deathSoundUrl);
    const imageTrigger = settings.getImageTrigger();
    if (imageTrigger.onDeath) {
        displayImage(imageTrigger.url, imageTrigger.duration);
    }
});

// Function to play the sound
function playSound(url) {
    // Assuming you have a method to play audio from a URL
    World.playSound(url, 1, 1);
}

// Function to display the image
function displayImage(url, duration) {
    const image = new Image(url);
    image.draw(50, 50, 200, 200); // Adjust the position and size as needed
    setTimeout(() => {
        image.remove();
    }, duration * 1000);
}

// Command to open the settings GUI
register("command", () => {
    gui.openGui();
}).setName("SoundMod").setAliases("sm");
